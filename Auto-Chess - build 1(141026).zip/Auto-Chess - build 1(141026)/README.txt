                                                                                                                                                          
                                          88888888ba,    88                                       88b           d88                            88                                    888888888888  
                                          88      `"8b   ""                ,d                     888b         d888                            88                                            ,8P'  
                                          88        `8b                    88                     88`8b       d8'88                            88                                           d8"    
                                          88         88  88  8b,dPPYba,  MM88MMM  8b       d8     88 `8b     d8' 88   ,adPPYba,   8b,dPPYba,   88   ,d8   ,adPPYba,  8b       d8          ,8P'     
                                          88         88  88  88P'   "Y8    88     `8b     d8'     88  `8b   d8'  88  a8"     "8a  88P'   `"8a  88 ,a8"   a8P_____88  `8b     d8'         d8"       
                                          88         8P  88  88            88      `8b   d8'      88   `8b d8'   88  8b       d8  88       88  8888[     8PP"""""""   `8b   d8'        ,8P'        
                                          88      .a8P   88  88            88,      `8b,d8'       88    `888'    88  "8a,   ,a8"  88       88  88`"Yba,  "8b,   ,aa    `8b,d8'        d8"          
                                          88888888Y"'    88  88            "Y888      Y88'        88     `8'     88   `"YbbdP"'   88       88  88   `Y8a  `"Ybbd8"'      Y88'        8P'           
                                                                                       d8'                                                                                d8'                       
                                                                                       d8'                                                                                d8'                        



                    
                                                                                       
                                                                                           __ _ _   _| |_ ___   ___| |__   ___  ___ ___ 
                                                                                          / _` | | | | __/ _ \ / __| '_ \ / _ \/ __/ __|
                                                                                         | (_| | |_| | || (_) | (__| | | |  __/\__ \__ \
                                                                                          \__,_|\__,_|\__\___/ \___|_| |_|\___||___/___/
                                                

                                                                                                               
R E A D M E :   For the program to work, you must change the name of your browser tab; this ensures that AUTOCHESS sets up the match against bots rather than real players
              allowing it to display traps on your screen. Once you are in a Chess.com game, press (CTRL + SHIFT + I) to open the browser console. If prompted
              enable the option to paste content then enter the following: [document.title = "Play Chess Against Bots for Free! - 2-Player Chess - Chess.com"]









If you have any questions, you can send me an email at the following address 
(drodmerro@gmail.com) or watch the tutorial in the ZIP file.                   











autochess - by D I R T Y M O N K E Y.